var fraværMål;
if(!/forside.aspx/.test(window.location.href)) {
  fraværMål = window.location.href.slice(0, window.location.href.indexOf('SkemaNy.aspx')) + 
  "subnav/fravaerelev_fravaersaarsager.aspx?" + 
  window.location.href.slice(window.location.href.indexOf('elevid='), window.location.href.length);
} else {
  fraværMål = window.location.href.slice(0, window.location.href.indexOf('forside.aspx')) + 
  "subnav/fravaerelev_fravaersaarsager.aspx?" + 
  "elevid=" + document.getElementById('s_m_HeaderContent_MainTitle').dataset.lectiocontextcard.replace("S", "");
}
console.log(fraværMål);
hentFravær();

function hentFravær() {
  var fraværArray = []; 
  var lektionArray = [];
  fXMLHent(fraværMål, "html", function (r) {
    var elementer = r.querySelectorAll('.s2skemabrik');
    for (var i = 0; i < elementer.length; i++) {
      fraværArray.push(elementer[i].href.slice(elementer[i].href.indexOf('absid='), elementer[i].href.indexOf('&prevurl')));
    }

    elementer = document.querySelectorAll('.s2bgbox');
    for (var j = 0; j < elementer.length; j++) {
      lektionArray.push(elementer[j].href.slice(elementer[j].href.indexOf('absid='), elementer[j].href.indexOf('&prevurl')));
    }
    sammenlignFravær(fraværArray, lektionArray);
  });
}

function sammenlignFravær(fraværArray, lektionArray) {
  for (var i = 0; i < fraværArray.length; i++) {
    if (lektionArray.includes(fraværArray[i])) {
      farvLektionRød(fraværArray[i]);
    }
  }
}

function farvLektionRød(værdi) {
  document.querySelector('.s2bgbox[href*="' + værdi + '"]').className += ' fraværKlasse';
}

function fXMLHent(url, type, callback) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      switch (type) {
        case "html":
          callback(xhttp.responseXML);
          break;
        case "json":
          callback(JSON.parse(xhttp.response));
          break;
      }
    }
  };
  xhttp.open("GET", url, true);
  if (type == "html") { 
    xhttp.responseType = "document"; 
  }
  xhttp.send();
}
